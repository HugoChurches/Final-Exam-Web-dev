import React from 'react';

function MovieForm(props) {
    return (
        <div>
            <form>
                <label for="movieQuery_title">Title:</label>
                <input type="text" class="movie-query" id="movieQuery_title" />
                <label for="movieQuery_year">Year:</label>
                <input type="text" class="movie-query" id="movieQuery_year" />
                <label for="movieQuery_rating">Rating:</label>
                <input type="text" class="movie-query" id="movieQuery_rating" />
            </form>
        </div>
    );
}

export default MovieForm;