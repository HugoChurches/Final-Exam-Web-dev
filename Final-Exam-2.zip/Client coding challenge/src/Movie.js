import React from 'react';

function Movie(props) {
    return (
        <div>
            {/* If I had the props set this is how it would look */}
            <p>Movie Title{this.state.movie_title}</p>
            <p>Movie Year{this.state.movie_year}</p>
            <p>Movie rating{this.state.movie_rating}</p>

        </div>
    );
}

export default Movie;