import React from 'react';
import './App.css';
//No need to import anything
import Movie from './Movie';
import MovieForm from './MovieForm';

class App extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      movie_title: "",
      movie_year: "",
      movie_rating: "",
      //Recall that here goes the information of the movies...
      //Communicate with the endpoint
      movieURL: "http://localhost:8080/api/movies"
    }
  }

  /*
    Your code goes here
  */

  //Fetch call goes here, get all the movies first...
  componentDidMount() {
    const url = `${this.state.movieURL}`;
    const settings = {
      method: 'GET',
      headers: { token: 'success-token' }
    }
  };

  //Don't know why am getting this error... 
  fetch(url, settings)
    .then(response => {
    if(response.ok){
  return response.json();
}
throw new Error(response, statusText);
    })

    .catch (err=> {
  throw new Error(response);
})


//Results here...
render() {
  return (
    <div>


    </div>
  );
}
}

export default App;
