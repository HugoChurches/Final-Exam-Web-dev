exports.DATABASE_URL = process.env.DATABASE_URL || "mongodb://localhost/moviedex";
exports.PORT = process.env.PORT || 8080;
exports.TOKEN = process.env.TOKEN || 'success-token';
