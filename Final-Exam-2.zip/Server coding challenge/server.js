const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const jsonParser = bodyParser.json();
const { DATABASE_URL, PORT } = require('./config');
const cors = require('./middleware/cors');
const validation = require('./middleware/token-validation');
const { v4: uuidv4 } = require('uuid');
const { request } = require('express');
const app = express();
const { Movies } = require('./models/moviedex-models');
app.use(cors);
app.use(validation);

/* 
    Your code goes here 
*/
//API endpoint -- /api/add-movie

// I made the following body of the request
// {
//     "movie_title" : "Test",
//     "movie_year" : "2000",
//     "movie_rating" : 9
// }
app.post('/api/add-movie', jsonParser, (req, res) => {
    console.log(req.body);
    let newMovie = {
        movie_title: req.body.movie_title,
        movie_year: req.body.movie_year,
        movie_rating: req.body.movie_rating,
        movie_id: uuidv4.v4()
    }
    console.log(req.body.movie_title);

    //Validations!
    if (!movie_title || !movie_year || !movie_rating) {
        res.statusMessage = "You need to send all movie fields to add the movie to the movie list";
        res.status(403).end();
    }

    //Cannot test this until schema is found...
    Movies
        .addNewMovie(newMovie)
        .then(result => {
            res.statusMessage = "Movie added";
            return res.status(201).json(result);
        })

    console.log(newMovie);

});

//API endpoint -- /api/movies
app.get('/api/movies', (req, res) => {
    Movies
        .getAllMovies()
        .then(result => {
            return res.status(200).json(result);
        })
        .catch(err => {
            res.statusMessage = "No movies found in the moviedex";
            return res.status(404).end();
        })

})

// I made the following body of the request
// {
//     "movie_title" : "Test",
//     "movie_year" : "2000",
//     "movie_rating" : 9
// }
app.get('/api/movies', jsonParser, (req, res) => {
    let title = "";
    let year = "";
    let rating = "";

    title = req.query.movie_title;
    year = req.query.movie_year;
    rating = req.query.movie_rating;

    if (!title || !year || !rating) {
        res.statusMessage = "Parameters missing in search query";
        return res.status(406).end();
    }

    let objectTitle = {
        'movie_title': title
    }

    Movies
        .findMovie(objectTitle)
        .then(result => {
            return res.status(200).json(result);
        })
        .catch(err => {
            res.statusMessage = "No movies found in the moviedex";
            return res.status(404).end();
        })


})



app.listen(PORT, () => {
    console.log("This server is running on port 8080");
    new Promise((resolve, reject) => {
        const settings = {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            useCreateIndex: true
        };
        mongoose.connect(DATABASE_URL, settings, (err) => {
            if (err) {
                return reject(err);
            }
            else {
                console.log("Database connected successfully.");
                return resolve();
            }
        })
    })
        .catch(err => {
            console.log(err);
        });
});