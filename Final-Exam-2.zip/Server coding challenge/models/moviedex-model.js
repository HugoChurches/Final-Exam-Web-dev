const mongoose = require('mongoose');
const uuid = require('uuid');

const moviedexSchema = mongoose.Schema({
    movie_title: {
        type: String,
        required: true
    },

    movie_year: {
        type: Number,
        required: true
    },

    movie_rating: {
        type: Number,
        required: true
    },

    movie_id: {
        type: String,
        required: true,
        unique: true
    }
});

const movieModel = mongoose.mongo.model('movies', moviedexSchema);

const Movies = {

    //Add a new movie
    addNewMovie: function (newMovie) {
        return movieModel
            .create(newMovie)
            .then(createdMovie => {
                return createdMovie;
            })
            .catch(err => {
                //Catch error on server
                throw new Error(err.message);
            });
    },

    //Get all the movies in the collection
    getAllMovies: function () {
        return movieModel
            .find()
            .then(allMovies => {
                return allMovies;
            })
            .catch(err => {
                //Catch error on server
                throw new Error(err.message);
            });

    },

    getMovie: function (title) {
        return movieModel
            .find(title)
            .then(foundMovie => {
                return foundMovie;
            })
            .catch(err => {
                return err;
            });
    }



}

module.exports = {
    Movies
};