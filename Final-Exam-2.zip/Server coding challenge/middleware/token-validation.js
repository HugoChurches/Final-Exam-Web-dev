function validateToken(req, res, next) {
    let token = req.headers.authorization;

    //Check if token was provided
    if (!token) {
        res.statusMessage = "You need to send the 'session-exam-token";
        return res.status(401).end();
    }

    //If the token doesn't match
    if (token !== `Bearer ${API_TOKEN}`) {
        res.statusMessage = "The session-exam-token is invalid";
        return res.status(401).end();
    }

    //If everything is ok then...
    next();
}

module.exports = validateToken;
